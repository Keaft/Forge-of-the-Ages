# Portal Super Cache
**for Minecraft Forge 1.12.2**

------

This mod is originally made with carpet mod for 1.13.2.

When using this mod, your game will search portal blocks at a high speed on teleport with the cost of slightly longer time of the first teleport.

This mode is still under development (Alpha). Use it with care and feel free to report the issues.
